require('colors');
const inquirer = require('inquirer');

const preguntas = [
    {
        type: 'list',
        name: 'opcion',
        message: '¿Que deseas hacer?',
        choices: [
            {
                value: '1',
                name: `${'1.'.yellow} ${'Añadir tarea'.green}`
            },
            {
                value: '2',
                name: `${'2.'.yellow} ${'Mostrar tareas'.green}`
            },
            {
                value: '3',
                name: `${'3.'.yellow} ${'Mostrar tareas completas'.green}`
            },
            {
                value: '4',
                name: `${'4.'.yellow} ${'Mostrar tareas incompletas'.green}`
            },
            {
                value: '5',
                name: `${'5.'.yellow} ${'Completar tarea(s)'.green}`
            },
            {
                value: '6',
                name: `${'6.'.yellow} ${'Borrar tarea(s)'.green}`
            },
            {
                value: '0',
                name: `${'0.'.yellow} ${'Salir'.green}`
            },
        ],
    },
];

const mostrarMenu = () => {
    return new Promise(resolve => {
      console.clear();
      console.log("*===================================================*".rainbow);
      console.log("               Seleccione una opcion                ".bgBlue);
      console.log("*===================================================*".rainbow);
      

      const readline = require('readline').createInterface({
        input: stdin,
        output: stdout
      });

      readline.question('Seleccione una opcion: ', (otp) => {
        readline.close();
        otp = otp;
        // console.log(opt);
        resolve(otp);

      });
    });
  };





  module.exports = {
    mostrarMenu
  };

